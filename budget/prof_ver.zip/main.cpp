#include "date.h"
#include "budget.h"

using namespace std;

int main()
{
  int command_count;
  cin >> command_count;
  Budget budget;
  while(command_count--) {
    istream& fake_cin = cin;

    SimpleDate from;
    SimpleDate to;
    int amount;

    string command;
    fake_cin >> command;
    if(command == "PayTax") {
      fake_cin >> from >> to >> amount;
      budget.PayTax(Date(from), Date(to), amount);
    } else if(command == "Earn") {
      SimpleDate from;
      SimpleDate to;
      fake_cin >> from >> to >> amount;
      budget.Incomes(Date(from), Date(to), amount);
    } else if(command == "Spend") {
      SimpleDate from;
      SimpleDate to;
      fake_cin >> from >> to >> amount;
      budget.Spend(Date(from), Date(to), amount);
    } else {
      SimpleDate from;
      SimpleDate to;
      fake_cin >> from >> to;
      auto total = budget.ComputeTotal(Date(from), Date(to));
      cout << setprecision(3) << fixed << total << '\n';
    }
  }
  return 0;
}
